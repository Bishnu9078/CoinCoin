'use strict';

module.exports = {
  HTTP_HOST: '0.0.0.0',
  HTTP_PORT: 10104,
  PROJECT_TITLE: 'Blockchain - Wallet'
};
