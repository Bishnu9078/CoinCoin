echo "Testing exchange service..."
cd exchange
pwd
npm run precommit
cd ..
echo "Testing miner service..."
cd miner
pwd
npm run precommit
cd ..
echo "Testing transaction service..."
cd transaction
pwd
npm run precommit
cd ..
echo "Testing wallet service..."
cd wallet
pwd
npm run precommit
