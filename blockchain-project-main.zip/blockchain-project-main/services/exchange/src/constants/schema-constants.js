'use strict';

const SCHEMA_API_LOCATION = 'src/schemas/api';

module.exports = {
  SCHEMA_LOCATION_V1: `${SCHEMA_API_LOCATION}/v1`
};
