'use strict';

module.exports = {
  message: 'Hello, World!',
  readinessURL: '/readiness',
  livenessURL: '/liveness'
};
