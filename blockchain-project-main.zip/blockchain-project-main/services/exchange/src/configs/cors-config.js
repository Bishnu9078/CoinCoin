'use strict';

module.exports = {
  origin: '*'
};
