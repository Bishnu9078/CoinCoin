'use strict';

module.exports = {
  NUMBER_OF_DECIMAL_PLACES: 4
};
