const AppConstants = {
  APP_NAME: 'CoinCoin',
  API_BASE_URL_EXCHANGE_DOMAIN: '//127.0.0.1:10101',
  API_BASE_URL_TRANSACTION_DOMAIN: '//127.0.0.1:10103'
};

export default AppConstants;